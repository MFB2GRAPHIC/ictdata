// ICT DATA configuration
const API_URL = "https://script.google.com/macros/s/AKfycbzSihlCS0PaLW0tKPxzWDkLRtkemiySRkqjLhl39xaSm0xi_iNtdpomBgFNth7LKei5uQ/exec";

// Change this before publishing.
// For a stronger production setup, use Google-account authentication on the backend.
const ADMIN_PAGE_PASSWORD = "2020";

// Must match ADMIN_KEY in Code.gs if you use the simple personal-project setup.
const ADMIN_API_KEY = "zutech-2026";
