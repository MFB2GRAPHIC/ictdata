const params = new URLSearchParams(location.search);
const year = params.get("year") || "";
const course = params.get("course") || "";

document.getElementById("yearText").textContent = year;
document.getElementById("courseText").textContent = course;
document.getElementById("bannerYear").textContent = year;
document.getElementById("bannerCourse").textContent = course;
document.title = `${course} | ICT DATA`;

let materials = [];
let activeType = "all";

async function load() {
  const box = document.getElementById("courseMaterials");
  const status = document.getElementById("courseStatus");

  if (API_URL.includes("PASTE_YOUR")) {
    status.textContent = "Connect Google Apps Script to load materials.";
    return;
  }

  try {
    const res = await fetch(API_URL);
    const all = await res.json();
    materials = all.filter(m => m.year === year && m.course === course);
    render();
  } catch {
    status.textContent = "Unable to load course materials.";
  }
}

function render() {
  const box = document.getElementById("courseMaterials");
  const status = document.getElementById("courseStatus");
  const shown = activeType === "all" ? materials : materials.filter(m => m.type === activeType);
  box.innerHTML = "";

  if (!shown.length) {
    status.textContent = "No materials have been added for this category yet.";
    return;
  }
  status.textContent = `${shown.length} material(s)`;

  shown.forEach(item => {
    const a = document.createElement("a");
    a.className = "material-item";
    a.href = item.url;
    a.target = "_blank";
    a.rel = "noopener noreferrer";
    a.innerHTML = `<span class="file-icon ${fileClass(item.url)}">${fileIcon(item.url)}</span>
      <span class="material-info"><b>${esc(item.title)}</b><small>${esc(item.type)}${item.description ? ` · ${esc(item.description)}` : ""}</small></span>
      <span class="open-file">Open File ↗</span>`;
    box.appendChild(a);
  });
}

function fileClass(url) { return /\.pdf/i.test(url) ? "pdf" : "drive"; }
function fileIcon(url) { return /\.pdf/i.test(url) ? "PDF" : "↗"; }
function esc(v) { return String(v ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c])); }

document.querySelectorAll(".tab").forEach(tab => {
  tab.addEventListener("click", () => {
    document.querySelectorAll(".tab").forEach(t => t.classList.remove("active"));
    tab.classList.add("active");
    activeType = tab.dataset.type;
    render();
  });
});

load();

// Mobile navigation
const menuButton = document.getElementById("menuButton");
const mainNav = document.querySelector(".nav nav");
if (menuButton && mainNav) {
  menuButton.addEventListener("click", () => {
    const open = mainNav.classList.toggle("open");
    menuButton.setAttribute("aria-expanded", String(open));
    menuButton.setAttribute("aria-label", open ? "Close menu" : "Open menu");
  });
  mainNav.querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
    mainNav.classList.remove("open");
    menuButton.setAttribute("aria-expanded", "false");
    menuButton.setAttribute("aria-label", "Open menu");
  }));
}
