# ICT DATA v2

This version visually follows the graphical mockup: navy/gold branding, hero section, year cards, course pages, material tabs, admin dashboard, statistics cards, Google Drive links and mobile responsive layout.

## Setup

1. Create a Google Sheet named ICT DATA Database.
2. Extensions > Apps Script.
3. Paste Code.gs.
4. Change ADMIN_KEY in Code.gs to your own secret.
5. Run setup() once and authorize it.
6. Deploy as a Web App, execute as you, and allow the required access.
7. Copy the Web App URL into config.js as API_URL.
8. Put the exact same API key into config.js as ADMIN_API_KEY.
9. Change ADMIN_PAGE_PASSWORD in config.js.
10. Publish the folder with GitHub Pages, Netlify, Cloudflare Pages, etc.

## Google Drive

Upload your actual files to Google Drive. Set appropriate sharing permissions. In the admin dashboard paste the Drive/Docs link only.

## Important security note

A password or API key placed in public JavaScript can be inspected by someone who downloads the site. This is acceptable only for a simple personal/student project where the Apps Script is treated as a lightweight backend. For a truly private administrator, replace the simple key with Google account authentication on the backend.

## Files

index.html - homepage
course.html - course materials page
admin.html - admin dashboard
style.css - complete visual design
script.js - homepage logic
course.js - course page logic
admin.js - dashboard logic
config.js - settings
Code.gs - Google Apps Script backend
