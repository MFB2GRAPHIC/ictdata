const COURSES = {
  "1st Year": ["ICT 1110"],
  "2nd Year": ["ICT 2010", "ICT 2021", "ICT 2022"],
  "3rd Year": ["ICT 3010", "ICT 3020", "ICT 3030"],
  "4th Year": ["ICT 4010", "ICT 4014", "ICT 4021", "ICT 9025", "ICT 9045", "ICT 9065"],
  "Other Courses": ["Other Courses"]
};

const loginPanel = document.getElementById("loginPanel");
const dashboard = document.getElementById("dashboard");
const yearEl = document.getElementById("year");
const courseEl = document.getElementById("course");

Object.keys(COURSES).forEach(y => yearEl.insertAdjacentHTML("beforeend", `<option>${y}</option>`));

function populateCourses() {
  courseEl.innerHTML = COURSES[yearEl.value].map(c => `<option>${c}</option>`).join("");
}
yearEl.addEventListener("change", populateCourses);
populateCourses();

document.getElementById("loginForm").addEventListener("submit", e => {
  e.preventDefault();
  if (document.getElementById("password").value === ADMIN_PAGE_PASSWORD) {
    sessionStorage.setItem("ictDataAdmin", "1");
    showDashboard();
  } else {
    document.getElementById("loginError").textContent = "Incorrect password.";
  }
});

function showDashboard() {
  loginPanel.classList.add("hidden");
  dashboard.classList.remove("hidden");
  loadMaterials();
}

function logout() {
  sessionStorage.removeItem("ictDataAdmin");
  location.reload();
}
document.getElementById("logoutBtn").addEventListener("click", logout);
document.getElementById("sideLogout").addEventListener("click", logout);

async function loadMaterials() {
  const table = document.getElementById("materialsTable");
  if (API_URL.includes("PASTE_YOUR")) {
    table.innerHTML = `<tr><td colspan="6">Connect Google Apps Script in config.js first.</td></tr>`;
    return;
  }
  try {
    const res = await fetch(API_URL);
    const data = await res.json();
    document.getElementById("totalMaterials").textContent = data.length;
    table.innerHTML = data.map(m => `<tr>
      <td>${esc(m.year)}</td><td>${esc(m.course)}</td><td>${esc(m.title)}</td><td>${esc(m.type)}</td>
      <td><a href="${esc(m.url)}" target="_blank">Open ↗</a></td>
      <td><button class="danger small" onclick="deleteMaterial('${escAttr(m.id)}')">Delete</button></td>
    </tr>`).join("") || `<tr><td colspan="6">No materials yet.</td></tr>`;
  } catch {
    table.innerHTML = `<tr><td colspan="6">Could not load materials.</td></tr>`;
  }
}

document.getElementById("materialForm").addEventListener("submit", async e => {
  e.preventDefault();
  const status = document.getElementById("saveStatus");
  status.textContent = "Saving...";
  if (API_URL.includes("PASTE_YOUR")) { status.textContent = "Connect Google Apps Script first."; return; }

  const payload = {
    action: "add",
    key: ADMIN_API_KEY,
    year: yearEl.value,
    course: courseEl.value,
    title: document.getElementById("title").value.trim(),
    type: document.getElementById("type").value,
    description: document.getElementById("description").value.trim(),
    url: document.getElementById("driveUrl").value.trim()
  };

  try {
    const res = await fetch(API_URL, {method:"POST", headers:{"Content-Type":"text/plain;charset=utf-8"}, body:JSON.stringify(payload)});
    const result = await res.json();
    if (!result.ok) throw new Error(result.error || "Save failed.");
    e.target.reset(); populateCourses(); status.textContent = "Material added successfully.";
    loadMaterials();
  } catch (err) { status.textContent = err.message; }
});

async function deleteMaterial(id) {
  if (!confirm("Delete this material?")) return;
  try {
    const res = await fetch(API_URL, {method:"POST", headers:{"Content-Type":"text/plain;charset=utf-8"}, body:JSON.stringify({action:"delete", key:ADMIN_API_KEY, id})});
    const result = await res.json();
    if (!result.ok) throw new Error(result.error || "Delete failed.");
    loadMaterials();
  } catch (err) { alert(err.message); }
}

document.getElementById("refreshBtn").addEventListener("click", loadMaterials);

function esc(v) { return String(v ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c])); }
function escAttr(v) { return String(v ?? "").replace(/'/g, "\\'"); }

if (sessionStorage.getItem("ictDataAdmin") === "1") showDashboard();
