const SHEET_NAME = "Materials";
const ADMIN_KEY = "ChangeThisApiKey";

function setup() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(SHEET_NAME);
  if (!sheet) sheet = ss.insertSheet(SHEET_NAME);
  if (sheet.getLastRow() === 0) {
    sheet.appendRow(["id","year","course","title","type","description","url","createdAt"]);
    sheet.setFrozenRows(1);
  }
}

function doGet() {
  setup();
  const values = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAME).getDataRange().getValues();
  const data = values.slice(1).filter(r => r[0]).map(r => ({
    id:String(r[0]), year:String(r[1]), course:String(r[2]), title:String(r[3]),
    type:String(r[4]), description:String(r[5] || ""), url:String(r[6])
  }));
  return json_(data);
}

function doPost(e) {
  try {
    const body = JSON.parse(e.postData.contents || "{}");
    if (body.key !== ADMIN_KEY) return json_({ok:false,error:"Unauthorized"});
    setup();
    const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAME);

    if (body.action === "add") {
      validate_(body);
      sheet.appendRow([Utilities.getUuid(),body.year,body.course,body.title,body.type || "Other",body.description || "",body.url,new Date()]);
      return json_({ok:true});
    }

    if (body.action === "delete") {
      const values = sheet.getDataRange().getValues();
      for (let i=1;i<values.length;i++) {
        if (String(values[i][0]) === String(body.id)) {
          sheet.deleteRow(i+1);
          return json_({ok:true});
        }
      }
      throw new Error("Material not found.");
    }

    throw new Error("Unknown action.");
  } catch(err) {
    return json_({ok:false,error:err.message});
  }
}

function validate_(b) {
  const years = ["1st Year","2nd Year","3rd Year","4th Year","Other Courses"];
  if (!years.includes(b.year)) throw new Error("Invalid year.");
  if (!b.course || !b.title || !b.url) throw new Error("Required fields are missing.");
  if (!/^https:\/\/(drive|docs)\.google\.com\//i.test(b.url)) throw new Error("Use a Google Drive/Docs link.");
}

function json_(data) {
  return ContentService.createTextOutput(JSON.stringify(data)).setMimeType(ContentService.MimeType.JSON);
}
