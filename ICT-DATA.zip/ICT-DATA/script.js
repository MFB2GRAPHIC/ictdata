const COURSES = {
  "1st Year": ["ICT 1110"],
  "2nd Year": ["ICT 2010", "ICT 2021", "ICT 2022"],
  "3rd Year": ["ICT 3010", "ICT 3020", "ICT 3030"],
  "4th Year": ["ICT 4010", "ICT 4014", "ICT 4021", "ICT 9025", "ICT 9045", "ICT 9065"],
  "Other Courses": ["Other Courses"]
};

let materials = [];
const yearsEl = document.getElementById("years");
const statusEl = document.getElementById("status");
const searchInput = document.getElementById("searchInput");

async function loadMaterials() {
  if (API_URL.includes("PASTE_YOUR")) {
    materials = [];
    statusEl.textContent = "Connect Google Apps Script to show your materials.";
    render();
    return;
  }
  try {
    const res = await fetch(API_URL);
    materials = await res.json();
    render();
  } catch {
    statusEl.textContent = "Unable to load materials. Check your Google Apps Script URL.";
  }
}

function render() {
  const q = searchInput.value.trim().toLowerCase();
  yearsEl.innerHTML = "";

  Object.entries(COURSES).forEach(([year, courses]) => {
    const filtered = courses.map(course => ({
      course,
      items: materials.filter(m => m.year === year && m.course === course &&
        (!q || `${m.title} ${m.course} ${m.type}`.toLowerCase().includes(q)))
    })).filter(g => !q || g.items.length);

    if (!filtered.length) return;

    const card = document.createElement("section");
    card.className = "year-card";
    const count = filtered.reduce((n, g) => n + g.items.length, 0);
    card.innerHTML = `<div class="year-card-head"><div class="year-icon">${yearIcon(year)}</div><div><h2>${year}</h2><span>${courseCount(year)} Courses${count ? ` · ${count} Materials` : ""}</span></div></div>`;

    filtered.forEach(group => {
      const course = document.createElement("div");
      course.className = "course-row";
      course.innerHTML = `<div><h3>${esc(group.course)}</h3><p>${group.items.length ? `${group.items.length} material(s)` : "No materials added yet"}</p></div>
        <a class="course-arrow" href="course.html?year=${encodeURIComponent(year)}&course=${encodeURIComponent(group.course)}">›</a>`;
      card.appendChild(course);
    });
    yearsEl.appendChild(card);
  });

  if (!yearsEl.children.length) statusEl.textContent = "No matching courses or materials.";
  else if (!API_URL.includes("PASTE_YOUR")) statusEl.textContent = "";
}

function courseCount(year) { return COURSES[year].length; }
function yearIcon(year) { return {"1st Year":"📖","2nd Year":"🎓","3rd Year":"💻","4th Year":"🎯","Other Courses":"📁"}[year]; }
function esc(v) { return String(v ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c])); }

searchInput.addEventListener("input", render);
document.getElementById("searchButton").addEventListener("click", () => searchInput.dispatchEvent(new Event("input")));
loadMaterials();

// Mobile navigation
const menuButton = document.getElementById("menuButton");
const mainNav = document.querySelector(".nav nav");
if (menuButton && mainNav) {
  menuButton.addEventListener("click", () => {
    const open = mainNav.classList.toggle("open");
    menuButton.setAttribute("aria-expanded", String(open));
    menuButton.setAttribute("aria-label", open ? "Close menu" : "Open menu");
  });
  mainNav.querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
    mainNav.classList.remove("open");
    menuButton.setAttribute("aria-expanded", "false");
    menuButton.setAttribute("aria-label", "Open menu");
  }));
}
